import React, { useState, useEffect } from 'react';
import { PhoneCall, Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white shadow-md py-2' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center">
          <div className="text-2xl font-bold text-blue-900">
            <span className="text-blue-700 mr-1">Flow</span>Masters
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <a href="#services" className="text-gray-800 hover:text-blue-700 font-medium transition-colors">Services</a>
          <a href="#testimonials" className="text-gray-800 hover:text-blue-700 font-medium transition-colors">Testimonials</a>
          <a href="#about" className="text-gray-800 hover:text-blue-700 font-medium transition-colors">About Us</a>
          <a href="#contact" className="text-gray-800 hover:text-blue-700 font-medium transition-colors">Contact</a>
          <a href="tel:+18005551234" className="flex items-center bg-blue-800 text-white px-4 py-2 rounded-md hover:bg-blue-900 transition-colors">
            <PhoneCall size={18} className="mr-2" />
            <span className="font-medium">(800) 555-1234</span>
          </a>
        </nav>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-blue-900"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      <div className={`md:hidden transition-all duration-300 overflow-hidden ${
        isMenuOpen ? 'max-h-screen opacity-100' : 'max-h-0 opacity-0'
      }`}>
        <div className="bg-white px-4 py-4 flex flex-col space-y-4">
          <a 
            href="#services" 
            className="text-gray-800 hover:text-blue-700 font-medium transition-colors py-2"
            onClick={() => setIsMenuOpen(false)}
          >
            Services
          </a>
          <a 
            href="#testimonials" 
            className="text-gray-800 hover:text-blue-700 font-medium transition-colors py-2"
            onClick={() => setIsMenuOpen(false)}
          >
            Testimonials
          </a>
          <a 
            href="#about" 
            className="text-gray-800 hover:text-blue-700 font-medium transition-colors py-2"
            onClick={() => setIsMenuOpen(false)}
          >
            About Us
          </a>
          <a 
            href="#contact" 
            className="text-gray-800 hover:text-blue-700 font-medium transition-colors py-2"
            onClick={() => setIsMenuOpen(false)}
          >
            Contact
          </a>
          <a 
            href="tel:+18005551234" 
            className="flex items-center bg-blue-800 text-white px-4 py-3 rounded-md hover:bg-blue-900 transition-colors justify-center"
            onClick={() => setIsMenuOpen(false)}
          >
            <PhoneCall size={18} className="mr-2" />
            <span className="font-medium">(800) 555-1234</span>
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;