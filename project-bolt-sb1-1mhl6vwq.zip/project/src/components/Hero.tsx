import React from 'react';
import { ArrowRight, Clock, ShieldCheck, PenTool as Tool } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="pt-28 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-blue-900 to-blue-800 text-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center">
          <div className="lg:w-1/2 mb-10 lg:mb-0">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 leading-tight">
              Expert Plumbing Solutions <br className="hidden md:block" />
              for Your Home
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-lg">
              From leaky faucets to complete repiping jobs, our licensed plumbers 
              provide fast, reliable service you can count on, 24/7.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <a 
                href="#service-selector" 
                className="bg-orange-500 hover:bg-orange-600 text-white font-medium py-3 px-6 rounded-md transition-all transform hover:scale-105 flex items-center justify-center"
              >
                Find Your Plumbing Solution
                <ArrowRight size={18} className="ml-2" />
              </a>
              <a 
                href="tel:+18005551234" 
                className="bg-white hover:bg-gray-100 text-blue-900 font-medium py-3 px-6 rounded-md transition-all transform hover:scale-105 flex items-center justify-center"
              >
                Call Now: (800) 555-1234
              </a>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex items-center">
                <Clock size={18} className="text-orange-500 mr-2" />
                <span className="text-sm">24/7 Emergency Service</span>
              </div>
              <div className="flex items-center">
                <ShieldCheck size={18} className="text-orange-500 mr-2" />
                <span className="text-sm">Licensed & Insured</span>
              </div>
              <div className="flex items-center">
                <Tool size={18} className="text-orange-500 mr-2" />
                <span className="text-sm">Satisfaction Guaranteed</span>
              </div>
            </div>
          </div>
          
          <div className="lg:w-1/2 relative">
            <div className="bg-white rounded-lg shadow-xl overflow-hidden transform rotate-1 transition-transform hover:rotate-0">
              <img 
                src="https://images.pexels.com/photos/8486976/pexels-photo-8486976.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Professional plumber at work" 
                className="w-full h-auto object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-blue-900 to-transparent py-6 px-4">
                <div className="bg-orange-500 text-white text-sm font-medium py-2 px-4 rounded-full inline-block">
                  Available Today!
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;