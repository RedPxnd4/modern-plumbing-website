import React, { useState } from 'react';
import { PhoneCall, Mail, MapPin, ArrowRight, Send } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { Service } from '../types';
import services from '../data/services';

interface ContactSectionProps {
  selectedService: Service | null;
}

const ContactSection: React.FC<ContactSectionProps> = ({ selectedService }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    serviceId: selectedService?.id || '',
    message: '',
    preferredContact: 'phone'
  });
  
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // In a real application, you would send this data to your backend
    setIsSubmitted(true);
    // Reset form after submission
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        name: '',
        email: '',
        phone: '',
        serviceId: selectedService?.id || '',
        message: '',
        preferredContact: 'phone'
      });
    }, 5000);
  };

  return (
    <section id="contact" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Contact Us</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Ready to solve your plumbing issues? Contact us today for a free quote or to schedule service.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              {isSubmitted ? (
                <div className="p-8 flex flex-col items-center justify-center min-h-[400px]">
                  <div className="bg-green-100 rounded-full p-3 mb-4">
                    <Send className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Thank You!</h3>
                  <p className="text-gray-600 text-center mb-6">
                    Your message has been sent successfully. One of our plumbing experts will contact you shortly.
                  </p>
                  <p className="text-sm text-gray-500">
                    For urgent issues, please call us directly at (800) 555-1234.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="p-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-6">Get a Free Quote</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                      required
                    />
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="serviceId" className="block text-sm font-medium text-gray-700 mb-1">
                      Select Your Plumbing Issue
                    </label>
                    <select
                      id="serviceId"
                      name="serviceId"
                      value={formData.serviceId}
                      onChange={handleChange}
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border bg-white"
                      required
                    >
                      <option value="">-- Select an issue --</option>
                      {services.map((service) => (
                        <option key={service.id} value={service.id}>
                          {service.title}
                        </option>
                      ))}
                      <option value="other">Other (Please describe)</option>
                    </select>
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                      Message
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={4}
                      value={formData.message}
                      onChange={handleChange}
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border"
                      placeholder="Please provide additional details about your plumbing issue..."
                    ></textarea>
                  </div>
                  
                  <div className="mb-6">
                    <span className="block text-sm font-medium text-gray-700 mb-2">
                      Preferred Contact Method
                    </span>
                    <div className="flex space-x-4">
                      <div className="flex items-center">
                        <input
                          type="radio"
                          id="phone-contact"
                          name="preferredContact"
                          value="phone"
                          checked={formData.preferredContact === 'phone'}
                          onChange={handleChange}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="phone-contact" className="ml-2 text-sm text-gray-700">
                          Phone
                        </label>
                      </div>
                      <div className="flex items-center">
                        <input
                          type="radio"
                          id="email-contact"
                          name="preferredContact"
                          value="email"
                          checked={formData.preferredContact === 'email'}
                          onChange={handleChange}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                        />
                        <label htmlFor="email-contact" className="ml-2 text-sm text-gray-700">
                          Email
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  <button
                    type="submit"
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white font-medium py-3 px-4 rounded-md transition-colors flex items-center justify-center"
                  >
                    Submit Request
                    <ArrowRight size={18} className="ml-2" />
                  </button>
                </form>
              )}
            </div>
            
            <div>
              <div className="bg-gradient-to-br from-blue-800 to-blue-700 rounded-xl shadow-md p-8 text-white mb-8">
                <h3 className="text-xl font-semibold mb-6">Contact Information</h3>
                
                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="bg-blue-700 p-2 rounded-full mr-4">
                      <PhoneCall className="h-5 w-5 text-blue-100" />
                    </div>
                    <div>
                      <p className="font-medium">Phone</p>
                      <a href="tel:+18005551234" className="text-blue-100 hover:text-white transition-colors">
                        (800) 555-1234
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-blue-700 p-2 rounded-full mr-4">
                      <Mail className="h-5 w-5 text-blue-100" />
                    </div>
                    <div>
                      <p className="font-medium">Email</p>
                      <a href="mailto:info@flowmasters.com" className="text-blue-100 hover:text-white transition-colors">
                        info@flowmasters.com
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-blue-700 p-2 rounded-full mr-4">
                      <MapPin className="h-5 w-5 text-blue-100" />
                    </div>
                    <div>
                      <p className="font-medium">Address</p>
                      <p className="text-blue-100">
                        123 Plumbing Way<br />
                        Anytown, USA 12345
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-xl shadow-md p-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-6">Service Hours</h3>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                    <span className="text-gray-700">Monday - Friday</span>
                    <span className="font-medium text-gray-900">7:00 AM - 8:00 PM</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                    <span className="text-gray-700">Saturday</span>
                    <span className="font-medium text-gray-900">8:00 AM - 5:00 PM</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                    <span className="text-gray-700">Sunday</span>
                    <span className="font-medium text-gray-900">8:00 AM - 4:00 PM</span>
                  </div>
                </div>
                
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <div className="flex items-center bg-blue-50 p-3 rounded-lg">
                    <div className="bg-blue-100 p-2 rounded-full mr-3">
                      <LucideIcons.Clock className="h-5 w-5 text-blue-700" />
                    </div>
                    <p className="text-sm text-blue-800">
                      <span className="font-medium">24/7 Emergency Service Available</span><br />
                      For after-hours emergencies, additional service fees may apply.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;