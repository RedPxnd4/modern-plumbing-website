import React from 'react';
import { Clock, CheckCircle } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { Service } from '../types';

// Type to access Lucide icons dynamically
type IconName = keyof typeof LucideIcons;

interface ServiceCardProps {
  service: Service;
  isSelected: boolean;
  onSelect: () => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, isSelected, onSelect }) => {
  // Dynamically get the icon from Lucide
  const IconComponent = LucideIcons[service.icon as IconName];
  
  // Map urgency levels to colors
  const urgencyColors: Record<string, { bg: string, text: string }> = {
    low: { bg: 'bg-green-100', text: 'text-green-800' },
    medium: { bg: 'bg-yellow-100', text: 'text-yellow-800' },
    high: { bg: 'bg-orange-100', text: 'text-orange-800' },
    emergency: { bg: 'bg-red-100', text: 'text-red-800' }
  };
  
  const urgencyColor = urgencyColors[service.urgencyLevel];

  return (
    <div 
      className={`rounded-lg overflow-hidden shadow-md transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg cursor-pointer ${
        isSelected 
          ? 'border-2 border-blue-500 ring-2 ring-blue-200'
          : 'border border-gray-200'
      }`}
      onClick={onSelect}
    >
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="bg-blue-100 p-3 rounded-full">
            {IconComponent && <IconComponent className="h-6 w-6 text-blue-700" />}
          </div>
          <div className={`${urgencyColor.bg} ${urgencyColor.text} py-1 px-3 rounded-full text-xs font-medium`}>
            {service.urgencyLevel === 'emergency' ? 'Emergency' : 
             service.urgencyLevel === 'high' ? 'Urgent' :
             service.urgencyLevel === 'medium' ? 'Standard' : 'Routine'}
          </div>
        </div>
        
        <h3 className="text-lg font-semibold text-gray-900 mb-2">{service.title}</h3>
        <p className="text-gray-600 text-sm mb-4">{service.description}</p>
        
        <div className="flex items-center text-sm text-gray-500 mb-3">
          <Clock className="h-4 w-4 mr-2" />
          <span>Response time: {service.estimatedResponseTime}</span>
        </div>
        
        <div className={`mt-4 pt-4 border-t border-gray-100 flex justify-between items-center ${
          isSelected ? 'opacity-100' : 'opacity-0'
        } transition-opacity duration-300`}>
          <span className="text-blue-700 text-sm font-medium">Selected</span>
          <CheckCircle className="h-5 w-5 text-blue-700" />
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;