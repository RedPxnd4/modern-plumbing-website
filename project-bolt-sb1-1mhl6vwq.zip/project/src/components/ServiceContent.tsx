import React, { useState } from 'react';
import { Service, FAQ } from '../types';
import faqs from '../data/faqs';
import { ChevronDown, ChevronUp, CheckCircle, AlertTriangle, Clock } from 'lucide-react';
import * as LucideIcons from 'lucide-react';

// Type to access Lucide icons dynamically
type IconName = keyof typeof LucideIcons;

interface ServiceContentProps {
  selectedService: Service | null;
}

const ServiceContent: React.FC<ServiceContentProps> = ({ selectedService }) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);
  
  if (!selectedService) return null;
  
  // Filter FAQs for the selected service
  const serviceFaqs = faqs.filter(faq => faq.serviceId === selectedService.id);
  
  // Dynamically get the icon from Lucide
  const IconComponent = LucideIcons[selectedService.icon as IconName];

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  // Determine urgency CSS classes
  const getUrgencyClasses = () => {
    switch(selectedService.urgencyLevel) {
      case 'emergency':
        return 'bg-red-50 border-red-200 text-red-800';
      case 'high':
        return 'bg-orange-50 border-orange-200 text-orange-800';
      case 'medium':
        return 'bg-yellow-50 border-yellow-200 text-yellow-800';
      default:
        return 'bg-green-50 border-green-200 text-green-800';
    }
  };

  return (
    <section id="service-content" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-10">
            <div className="bg-gradient-to-r from-blue-800 to-blue-700 p-6 text-white">
              <div className="flex items-center mb-2">
                {IconComponent && <IconComponent className="h-6 w-6 mr-3" />}
                <h2 className="text-2xl font-bold">{selectedService.title}</h2>
              </div>
              <p className="text-blue-100 max-w-3xl">{selectedService.description}</p>
            </div>
            
            <div className="p-6">
              <div className="flex flex-col md:flex-row md:space-x-6 mb-8">
                <div className="md:w-1/2 mb-6 md:mb-0">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Common Solutions</h3>
                  <ul className="space-y-3">
                    {selectedService.commonSolutions?.map((solution, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{solution}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="md:w-1/2">
                  <div className={`border ${getUrgencyClasses()} rounded-lg p-4 mb-4`}>
                    <div className="flex items-center mb-2">
                      {selectedService.urgencyLevel === 'emergency' ? (
                        <AlertTriangle className="h-5 w-5 mr-2" />
                      ) : (
                        <Clock className="h-5 w-5 mr-2" />
                      )}
                      <h4 className="font-medium">Priority Level</h4>
                    </div>
                    <p className="text-sm">
                      {selectedService.urgencyLevel === 'emergency' 
                        ? 'This issue requires immediate attention to prevent property damage or safety hazards.'
                        : selectedService.urgencyLevel === 'high'
                        ? 'This issue should be addressed quickly to prevent worsening problems.'
                        : selectedService.urgencyLevel === 'medium'
                        ? 'This issue should be addressed soon but isn\'t an immediate emergency.'
                        : 'This issue can be scheduled at your convenience.'}
                    </p>
                  </div>
                  
                  <div className="bg-blue-50 rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <Clock className="h-5 w-5 text-blue-700 mr-2" />
                      <h4 className="font-medium text-blue-900">Expected Response Time</h4>
                    </div>
                    <p className="text-sm text-blue-800">{selectedService.estimatedResponseTime}</p>
                  </div>
                </div>
              </div>
              
              <div className="pt-6 border-t border-gray-200">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-gray-900">Frequently Asked Questions</h3>
                  <a href="#contact" className="text-blue-700 hover:text-blue-900 text-sm font-medium">
                    Have another question?
                  </a>
                </div>
                
                <div className="space-y-4">
                  {serviceFaqs.length > 0 ? (
                    serviceFaqs.map((faq, index) => (
                      <div key={faq.id} className="border border-gray-200 rounded-lg overflow-hidden">
                        <button
                          className="w-full px-4 py-3 text-left flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
                          onClick={() => toggleFaq(index)}
                        >
                          <span className="font-medium text-gray-900">{faq.question}</span>
                          {openFaqIndex === index ? (
                            <ChevronUp className="h-5 w-5 text-gray-500" />
                          ) : (
                            <ChevronDown className="h-5 w-5 text-gray-500" />
                          )}
                        </button>
                        
                        <div 
                          className={`px-4 py-3 bg-white transition-all duration-300 ${
                            openFaqIndex === index ? 'block' : 'hidden'
                          }`}
                        >
                          <p className="text-gray-700">{faq.answer}</p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 italic">No frequently asked questions available for this service.</p>
                  )}
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div className="mb-4 sm:mb-0">
                <p className="text-gray-700 font-medium">Need help with this issue?</p>
                <p className="text-sm text-gray-500">Our expert plumbers are ready to assist you.</p>
              </div>
              <div className="flex space-x-4">
                <a 
                  href="#contact" 
                  className="bg-blue-700 hover:bg-blue-800 text-white font-medium py-2 px-6 rounded-md transition-colors"
                >
                  Get a Quote
                </a>
                <a 
                  href="tel:+18005551234" 
                  className="bg-white border border-blue-700 text-blue-700 hover:bg-blue-50 font-medium py-2 px-6 rounded-md transition-colors"
                >
                  Call Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServiceContent;