import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Star, Quote } from 'lucide-react';
import allTestimonials from '../data/testimonials';
import { Testimonial, Service } from '../types';

interface TestimonialsProps {
  selectedService: Service | null;
}

const Testimonials: React.FC<TestimonialsProps> = ({ selectedService }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [testimonials, setTestimonials] = useState<Testimonial[]>(allTestimonials);
  
  useEffect(() => {
    if (selectedService) {
      // Filter testimonials related to the selected service if available
      const filtered = allTestimonials.filter(
        t => t.serviceId === selectedService.id
      );
      
      // If we have service-specific testimonials, use them; otherwise use all
      setTestimonials(filtered.length > 0 ? filtered : allTestimonials);
      setCurrentIndex(0); // Reset index when changing testimonials
    } else {
      setTestimonials(allTestimonials);
    }
  }, [selectedService]);
  
  const goToPrevious = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };
  
  const goToNext = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
    );
  };
  
  // Generate stars based on rating
  const renderStars = (rating: number) => {
    return Array(5).fill(0).map((_, i) => (
      <Star 
        key={i} 
        className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
      />
    ));
  };

  return (
    <section id="testimonials" className="py-16 bg-blue-50">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What Our Customers Say</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              {selectedService 
                ? `Here's what customers are saying about our ${selectedService.title.toLowerCase()} services.`
                : 'Hear from our satisfied customers about their experience with our plumbing services.'}
            </p>
          </div>
          
          {testimonials.length > 0 ? (
            <div className="relative">
              <div className="overflow-hidden">
                <div 
                  className="flex transition-transform duration-500 ease-in-out"
                  style={{ transform: `translateX(-${currentIndex * 100}%)` }}
                >
                  {testimonials.map((testimonial) => (
                    <div 
                      key={testimonial.id} 
                      className="min-w-full px-4"
                    >
                      <div className="bg-white rounded-xl shadow-md overflow-hidden">
                        <div className="p-8">
                          <div className="flex items-center mb-6">
                            <div className="mr-4">
                              <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-blue-100">
                                <img 
                                  src={testimonial.imageUrl} 
                                  alt={testimonial.name} 
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            </div>
                            <div>
                              <h3 className="font-semibold text-lg text-gray-900">{testimonial.name}</h3>
                              <p className="text-gray-500 text-sm">{testimonial.location}</p>
                              <div className="flex mt-1">
                                {renderStars(testimonial.rating)}
                              </div>
                            </div>
                          </div>
                          
                          <div className="relative">
                            <Quote className="absolute top-0 left-0 h-8 w-8 text-blue-100 transform -translate-x-2 -translate-y-2" />
                            <p className="text-gray-700 relative z-10 pl-3">
                              "{testimonial.comment}"
                            </p>
                          </div>
                          
                          <div className="mt-6 pt-4 border-t border-gray-100">
                            <p className="text-blue-700 font-medium">
                              Service: {testimonial.service}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {testimonials.length > 1 && (
                <div className="flex justify-center mt-8 space-x-2">
                  <button 
                    className="p-2 rounded-full bg-white shadow-md hover:bg-gray-100 transition-colors border border-gray-200"
                    onClick={goToPrevious}
                  >
                    <ChevronLeft className="h-5 w-5 text-gray-600" />
                  </button>
                  
                  <div className="flex space-x-1 items-center">
                    {testimonials.map((_, index) => (
                      <button
                        key={index}
                        className={`w-2 h-2 rounded-full ${
                          currentIndex === index ? 'bg-blue-700' : 'bg-gray-300'
                        }`}
                        onClick={() => setCurrentIndex(index)}
                      />
                    ))}
                  </div>
                  
                  <button 
                    className="p-2 rounded-full bg-white shadow-md hover:bg-gray-100 transition-colors border border-gray-200"
                    onClick={goToNext}
                  >
                    <ChevronRight className="h-5 w-5 text-gray-600" />
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-md p-8 text-center">
              <p className="text-gray-500">No testimonials available for this service yet.</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;