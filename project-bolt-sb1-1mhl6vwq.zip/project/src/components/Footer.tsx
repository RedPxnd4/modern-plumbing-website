import React from 'react';
import { PhoneCall, Mail, Facebook, Instagram, Twitter, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-blue-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="text-2xl font-bold mb-4">
              <span className="text-blue-400 mr-1">Flow</span>Masters
            </div>
            <p className="text-blue-200 mb-6">
              Professional plumbing solutions for residential and commercial properties. Available 24/7 for all your plumbing needs.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-blue-800 p-2 rounded-full hover:bg-blue-700 transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="bg-blue-800 p-2 rounded-full hover:bg-blue-700 transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="bg-blue-800 p-2 rounded-full hover:bg-blue-700 transition-colors">
                <Twitter size={18} />
              </a>
              <a href="#" className="bg-blue-800 p-2 rounded-full hover:bg-blue-700 transition-colors">
                <Linkedin size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">Emergency Plumbing</a></li>
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">Drain Cleaning</a></li>
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">Water Heater Service</a></li>
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">Pipe Repair & Replacement</a></li>
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">Fixture Installation</a></li>
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">Sewer Line Services</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">Our Team</a></li>
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">Careers</a></li>
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">Testimonials</a></li>
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">Blog</a></li>
              <li><a href="#" className="text-blue-200 hover:text-white transition-colors">FAQ</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <PhoneCall size={18} className="mr-3 text-blue-400 mt-1" />
                <div>
                  <p className="text-sm text-blue-200">Call us 24/7</p>
                  <a href="tel:+18005551234" className="text-white hover:text-blue-200 transition-colors">
                    (800) 555-1234
                  </a>
                </div>
              </li>
              <li className="flex items-start">
                <Mail size={18} className="mr-3 text-blue-400 mt-1" />
                <div>
                  <p className="text-sm text-blue-200">Email us</p>
                  <a href="mailto:info@flowmasters.com" className="text-white hover:text-blue-200 transition-colors">
                    info@flowmasters.com
                  </a>
                </div>
              </li>
            </ul>
            
            <div className="mt-6 pt-6 border-t border-blue-800">
              <a 
                href="#contact"
                className="bg-orange-500 hover:bg-orange-600 text-white font-medium py-2 px-4 rounded-md transition-colors inline-block"
              >
                Request Service
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-blue-800 text-center text-blue-300 text-sm">
          <p>&copy; {currentYear} FlowMasters Plumbing. All rights reserved.</p>
          <div className="mt-2 space-x-4">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Accessibility</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;