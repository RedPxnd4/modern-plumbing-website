import React from 'react';
import * as LucideIcons from 'lucide-react';
import { certifications, statistics } from '../data/certifications';

// Type to access Lucide icons dynamically
type IconName = keyof typeof LucideIcons;

const TrustBuilders: React.FC = () => {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose FlowMasters</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              With over 25 years of experience, our licensed plumbers provide trustworthy, 
              professional service for all your plumbing needs.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
            {statistics.map((stat) => {
              const IconComponent = LucideIcons[stat.icon as IconName];
              
              return (
                <div key={stat.id} className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                    {IconComponent && <IconComponent className="h-8 w-8 text-blue-700" />}
                  </div>
                  <div className="text-3xl font-bold text-blue-900 mb-1">{stat.value}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              );
            })}
          </div>
          
          <div className="bg-blue-50 rounded-xl p-8 mb-16">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">Our Certifications</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {certifications.map((cert) => {
                const IconComponent = LucideIcons[cert.icon as IconName];
                
                return (
                  <div key={cert.id} className="flex bg-white rounded-lg p-4 shadow-sm">
                    <div className="mr-4 flex-shrink-0">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        {IconComponent && <IconComponent className="h-6 w-6 text-blue-700" />}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">{cert.name}</h4>
                      <p className="text-sm text-gray-600">{cert.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-blue-900 to-blue-800 rounded-xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-8 text-white">
                <h3 className="text-2xl font-bold mb-4">Our Promise To You</h3>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="bg-blue-800 rounded-full p-1 mr-3 mt-1">
                      <LucideIcons.Check className="h-4 w-4 text-blue-200" />
                    </div>
                    <div>
                      <p className="font-medium mb-1">Upfront, Honest Pricing</p>
                      <p className="text-blue-100 text-sm">No hidden fees or surprise charges</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-blue-800 rounded-full p-1 mr-3 mt-1">
                      <LucideIcons.Check className="h-4 w-4 text-blue-200" />
                    </div>
                    <div>
                      <p className="font-medium mb-1">On-Time Service</p>
                      <p className="text-blue-100 text-sm">We respect your schedule and arrive when promised</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-blue-800 rounded-full p-1 mr-3 mt-1">
                      <LucideIcons.Check className="h-4 w-4 text-blue-200" />
                    </div>
                    <div>
                      <p className="font-medium mb-1">Clean, Professional Work</p>
                      <p className="text-blue-100 text-sm">We leave your home as clean as we found it</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-blue-800 rounded-full p-1 mr-3 mt-1">
                      <LucideIcons.Check className="h-4 w-4 text-blue-200" />
                    </div>
                    <div>
                      <p className="font-medium mb-1">100% Satisfaction Guarantee</p>
                      <p className="text-blue-100 text-sm">We're not satisfied until you are</p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="relative h-full min-h-[300px] md:min-h-full">
                <img 
                  src="https://images.pexels.com/photos/5976589/pexels-photo-5976589.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                  alt="Professional plumbers" 
                  className="absolute inset-0 w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustBuilders;