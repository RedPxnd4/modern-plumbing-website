import React, { useState, useEffect } from 'react';
import { Search, Plus, AlertCircle } from 'lucide-react';
import services from '../data/services';
import { Service } from '../types';
import ServiceCard from './ServiceCard';

const ServiceSelector: React.FC<{
  onServiceSelect: (service: Service | null) => void;
}> = ({ onServiceSelect }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showOtherInput, setShowOtherInput] = useState(false);
  const [otherIssue, setOtherIssue] = useState('');
  const [filteredServices, setFilteredServices] = useState(services);
  const [selectedService, setSelectedService] = useState<Service | null>(null);

  useEffect(() => {
    if (searchTerm) {
      const filtered = services.filter(service => 
        service.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        service.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredServices(filtered);
    } else {
      setFilteredServices(services);
    }
  }, [searchTerm]);

  const handleServiceSelect = (service: Service) => {
    setSelectedService(service);
    onServiceSelect(service);
    setShowOtherInput(false);
    
    // Scroll to content section
    document.getElementById('service-content')?.scrollIntoView({
      behavior: 'smooth'
    });
  };

  const handleOtherSelect = () => {
    setShowOtherInput(true);
    setSelectedService(null);
    onServiceSelect(null);
  };

  const handleOtherSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle custom issue
    // In a real application, this might trigger a special contact form or live chat
    console.log("Custom issue submitted:", otherIssue);
    
    // Scroll to contact form
    document.getElementById('contact')?.scrollIntoView({
      behavior: 'smooth'
    });
  };

  return (
    <section id="service-selector" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">What plumbing issue are you experiencing?</h2>
          <p className="text-lg text-gray-600 mb-8">
            Select the option that best describes your problem, or use the search to find specific issues.
          </p>
          
          <div className="relative mb-10">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search for your plumbing issue..."
              className="block w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {showOtherInput ? (
          <div className="max-w-xl mx-auto bg-blue-50 p-6 rounded-lg shadow-md mb-12">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Tell us about your specific issue</h3>
            <form onSubmit={handleOtherSubmit}>
              <textarea
                className="block w-full p-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 mb-4"
                rows={4}
                placeholder="Please describe your plumbing issue in detail..."
                value={otherIssue}
                onChange={(e) => setOtherIssue(e.target.value)}
                required
              ></textarea>
              <div className="flex items-center space-x-4">
                <button
                  type="submit"
                  className="bg-blue-700 hover:bg-blue-800 text-white font-medium py-2 px-4 rounded-md transition-all"
                >
                  Submit Issue
                </button>
                <button
                  type="button"
                  className="text-blue-700 hover:text-blue-900 font-medium"
                  onClick={() => setShowOtherInput(false)}
                >
                  Back to Services
                </button>
              </div>
              <div className="mt-4 flex items-start text-left">
                <AlertCircle size={18} className="text-blue-700 mt-1 mr-2 flex-shrink-0" />
                <p className="text-sm text-gray-600">
                  For urgent issues, please call us directly at <strong>(800) 555-1234</strong> for immediate assistance.
                </p>
              </div>
            </form>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredServices.map((service) => (
              <ServiceCard 
                key={service.id} 
                service={service} 
                isSelected={selectedService?.id === service.id}
                onSelect={() => handleServiceSelect(service)}
              />
            ))}
            
            {/* Other option */}
            <div 
              className={`bg-gray-50 hover:bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                searchTerm ? 'hidden' : ''
              }`}
              onClick={handleOtherSelect}
            >
              <div className="bg-blue-100 p-3 rounded-full mb-4">
                <Plus className="h-6 w-6 text-blue-700" />
              </div>
              <h3 className="font-medium text-gray-900 mb-1">Other Issue</h3>
              <p className="text-sm text-gray-500">
                Don't see your problem? Describe it to us.
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default ServiceSelector;