import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ServiceSelector from './components/ServiceSelector';
import ServiceContent from './components/ServiceContent';
import Testimonials from './components/Testimonials';
import TrustBuilders from './components/TrustBuilders';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import { Service } from './types';

function App() {
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  
  const handleServiceSelect = (service: Service | null) => {
    setSelectedService(service);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <ServiceSelector onServiceSelect={handleServiceSelect} />
      <ServiceContent selectedService={selectedService} />
      <Testimonials selectedService={selectedService} />
      <TrustBuilders />
      <ContactSection selectedService={selectedService} />
      <Footer />
    </div>
  );
}

export default App;