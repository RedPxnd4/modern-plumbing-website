export interface Service {
  id: string;
  title: string;
  icon: string;
  description: string;
  urgencyLevel: 'low' | 'medium' | 'high' | 'emergency';
  estimatedResponseTime: string;
  commonSolutions?: string[];
}

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  service: string;
  rating: number;
  comment: string;
  imageUrl: string;
  serviceId?: string;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  serviceId: string;
}

export interface Certification {
  id: string;
  name: string;
  icon: string;
  description: string;
}

export interface Statistic {
  id: string;
  value: string;
  label: string;
  icon: string;
}