import { Certification, Statistic } from '../types';

export const certifications: Certification[] = [
  {
    id: 'cert1',
    name: 'Licensed Master Plumber',
    icon: 'Award',
    description: 'Our team is led by licensed master plumbers with advanced training and certification'
  },
  {
    id: 'cert2',
    name: 'Better Business Bureau A+ Rating',
    icon: 'BadgeCheck',
    description: 'Consistently maintaining the highest standards of customer service and business practices'
  },
  {
    id: 'cert3',
    name: 'Certified Green Plumbing Contractor',
    icon: 'Leaf',
    description: 'Specialized in water conservation and eco-friendly plumbing solutions'
  },
  {
    id: 'cert4',
    name: 'Home Advisor Top Rated',
    icon: 'Star',
    description: 'Recognized excellence based on verified customer reviews and satisfaction'
  }
];

export const statistics: Statistic[] = [
  {
    id: 'stat1',
    value: '25+',
    label: 'Years in Business',
    icon: 'Calendar'
  },
  {
    id: 'stat2',
    value: '15,000+',
    label: 'Satisfied Customers',
    icon: 'Users'
  },
  {
    id: 'stat3',
    value: '24/7',
    label: 'Emergency Service',
    icon: 'Clock'
  },
  {
    id: 'stat4',
    value: '100%',
    label: 'Satisfaction Guarantee',
    icon: 'ThumbsUp'
  }
];