import { FAQ } from '../types';

const faqs: FAQ[] = [
  // Leaky Faucet FAQs
  {
    id: 'faq-1',
    question: 'Why is my faucet dripping even when it\'s turned off?',
    answer: 'Faucets typically drip because of worn-out washers, O-rings, or cartridges that no longer create a proper seal. Over time, these components wear down from regular use and mineral deposits, allowing small amounts of water to escape. Our technicians can quickly identify the specific cause and replace the necessary parts.',
    serviceId: 'leaky-faucet'
  },
  {
    id: 'faq-2',
    question: 'How much water does a leaky faucet waste?',
    answer: 'Even a slow drip can waste significant amounts of water. A faucet dripping once per second can waste about 3,000 gallons per year—that\'s enough to take over 180 showers! Fixing leaky faucets is not only good for your water bill but also for water conservation efforts.',
    serviceId: 'leaky-faucet'
  },
  
  // Clogged Drain FAQs
  {
    id: 'faq-3',
    question: 'What should I avoid putting down my drains?',
    answer: 'To prevent clogs, avoid putting grease, coffee grounds, eggshells, and starchy foods down kitchen drains. In bathrooms, hair and soap scum are common culprits. Consider using drain screens and periodically flushing drains with hot water to maintain proper flow.',
    serviceId: 'clogged-drain'
  },
  {
    id: 'faq-4',
    question: 'Are chemical drain cleaners safe to use?',
    answer: 'We generally discourage the use of chemical drain cleaners as they can damage pipes, especially in older homes. These harsh chemicals can also harm the environment and pose health risks. Professional cleaning methods like snaking or hydro jetting are more effective and safer for your plumbing system.',
    serviceId: 'clogged-drain'
  },
  
  // No Hot Water FAQs
  {
    id: 'faq-5',
    question: 'Why did my hot water suddenly stop working?',
    answer: 'Sudden loss of hot water could be due to a failed heating element, tripped circuit breaker, gas supply issues, or a faulty thermostat. In some cases, sediment buildup in the tank can cause heating problems. Our technicians can diagnose the specific issue and recommend the most cost-effective solution.',
    serviceId: 'no-hot-water'
  },
  {
    id: 'faq-6',
    question: 'How long should my water heater last?',
    answer: 'Most traditional tank water heaters last 8-12 years with proper maintenance, while tankless models can last up to 20 years. Factors affecting lifespan include water quality, maintenance frequency, and usage patterns. Regular flushing and anode rod replacement can significantly extend your water heater\'s service life.',
    serviceId: 'no-hot-water'
  },
  
  // Running Toilet FAQs
  {
    id: 'faq-7',
    question: 'Why does my toilet keep running after flushing?',
    answer: 'A running toilet is usually caused by a faulty flapper valve that isn\'t sealing properly, a misadjusted fill valve allowing water to continuously flow into the overflow tube, or a problem with the flush valve chain. These issues prevent the toilet from completing its flush cycle correctly.',
    serviceId: 'running-toilet'
  },
  {
    id: 'faq-8',
    question: 'How much water does a running toilet waste?',
    answer: 'A continuously running toilet can waste up to 200 gallons of water per day—that\'s 6,000 gallons a month! This can dramatically increase your water bill. The good news is that most running toilet issues are relatively inexpensive to fix compared to the cost of wasted water.',
    serviceId: 'running-toilet'
  },
  
  // Low Water Pressure FAQs
  {
    id: 'faq-9',
    question: 'What causes low water pressure throughout my house?',
    answer: 'House-wide low pressure can be caused by a partially closed main water valve, a pressure regulator issue, mineral buildup in pipes, or municipal supply problems. Sometimes water leaks can also reduce pressure. Our comprehensive inspection can identify the exact cause.',
    serviceId: 'low-water-pressure'
  },
  {
    id: 'faq-10',
    question: 'Can old pipes cause low water pressure?',
    answer: 'Yes, older galvanized pipes often develop interior corrosion and mineral buildup that restricts water flow. This is common in homes built before 1960. In severe cases, repiping with modern materials like copper or PEX might be the most effective long-term solution.',
    serviceId: 'low-water-pressure'
  },
  
  // FAQs for each remaining service
  {
    id: 'faq-11',
    question: 'How do I know if I have a hidden water leak?',
    answer: 'Signs of hidden leaks include unexplained increases in water bills, the sound of running water when no fixtures are in use, damp spots on walls or floors, mildew or mold growth, and warm spots on floors (for hot water lines). Our professional leak detection service uses specialized equipment to locate leaks without unnecessary damage to your property.',
    serviceId: 'leaky-pipes'
  },
  
  {
    id: 'faq-12',
    question: 'What\'s the difference between a slow drain and a clog?',
    answer: 'A slow drain indicates a partial blockage that allows water to pass but at a reduced rate. This often results from buildup of hair, soap, and debris on pipe walls. A complete clog blocks all water flow. Slow drains should be addressed promptly as they typically worsen over time and can develop into full blockages.',
    serviceId: 'slow-draining-sink'
  },
  
  {
    id: 'faq-13',
    question: 'What should I do if my toilet is overflowing?',
    answer: 'First, turn off the water supply to the toilet using the shutoff valve located near the floor. Then remove the tank lid and lift the float to stop water flow. If water continues to rise, remove some water from the bowl using a cup and bucket. Once the immediate overflow is managed, you can attempt to clear the clog with a plunger or call us for professional assistance.',
    serviceId: 'clogged-toilet'
  },
  
  {
    id: 'faq-14',
    question: 'Should I repair or replace my old water heater?',
    answer: 'If your water heater is over 10 years old and experiencing problems, replacement is often more economical than repair. Newer models offer significant energy efficiency improvements that can reduce utility bills. However, if the unit is newer and the issue is a simple component failure, repair may be the better option. We can provide a cost-benefit analysis to help you make an informed decision.',
    serviceId: 'water-heater-issues'
  },
  
  {
    id: 'faq-15',
    question: 'What are the warning signs of a sewer line problem?',
    answer: 'Warning signs include multiple drains backing up simultaneously, gurgling toilets, sewage odors, lush patches of grass in your yard, indentations in lawn or paved areas, and foundation cracks or settling. Sewer line issues should be addressed immediately to prevent property damage and health hazards.',
    serviceId: 'sewer-line-problems'
  }
];

export default faqs;