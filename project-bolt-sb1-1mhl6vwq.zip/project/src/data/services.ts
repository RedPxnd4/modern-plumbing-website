import { Service } from '../types';

const services: Service[] = [
  {
    id: 'leaky-faucet',
    title: 'Leaky Faucet',
    icon: 'Droplet',
    description: 'Constant dripping from faucets wastes water and can lead to higher bills.',
    urgencyLevel: 'low',
    estimatedResponseTime: 'Same day or next day',
    commonSolutions: [
      'Replace worn washers or O-rings',
      'Tighten loose parts',
      'Replace the entire faucet if outdated'
    ]
  },
  {
    id: 'clogged-drain',
    title: 'Clogged Drain',
    icon: 'Pipette',
    description: 'Slow or completely blocked drains in sinks, showers, or tubs.',
    urgencyLevel: 'medium',
    estimatedResponseTime: 'Same day',
    commonSolutions: [
      'Professional drain snaking',
      'Hydro jetting for complete cleaning',
      'Camera inspection for recurring clogs'
    ]
  },
  {
    id: 'no-hot-water',
    title: 'No Hot Water',
    icon: 'Thermometer',
    description: 'Issues with water heater resulting in cold or lukewarm water.',
    urgencyLevel: 'high',
    estimatedResponseTime: 'Within 4-6 hours',
    commonSolutions: [
      'Water heater repair',
      'Thermostat adjustment',
      'Heating element replacement',
      'Complete water heater replacement'
    ]
  },
  {
    id: 'running-toilet',
    title: 'Running Toilet',
    icon: 'Toilet',
    description: 'Toilet that continues to run, wasting water and increasing utility bills.',
    urgencyLevel: 'medium',
    estimatedResponseTime: 'Same day',
    commonSolutions: [
      'Flapper valve replacement',
      'Fill valve adjustment or replacement',
      'Float arm adjustment'
    ]
  },
  {
    id: 'low-water-pressure',
    title: 'Low Water Pressure',
    icon: 'Gauge',
    description: 'Reduced water flow from fixtures throughout your home.',
    urgencyLevel: 'medium',
    estimatedResponseTime: 'Same day or next day',
    commonSolutions: [
      'Cleaning aerators and shower heads',
      'Pressure regulator adjustment',
      'Pipe inspection for leaks or corrosion'
    ]
  },
  {
    id: 'leaky-pipes',
    title: 'Leaky Pipes',
    icon: 'PipeLine',
    description: 'Water leaking from pipes, causing damage and water waste.',
    urgencyLevel: 'high',
    estimatedResponseTime: 'Within 2-4 hours',
    commonSolutions: [
      'Pipe section replacement',
      'Joint repair',
      'Complete repiping for older homes'
    ]
  },
  {
    id: 'slow-draining-sink',
    title: 'Slow Draining Sink',
    icon: 'Clock',
    description: 'Water that drains slowly from sinks, indicating partial blockage.',
    urgencyLevel: 'low',
    estimatedResponseTime: 'Same day or next day',
    commonSolutions: [
      'Drain cleaning service',
      'P-trap cleaning',
      'Drain line inspection'
    ]
  },
  {
    id: 'clogged-toilet',
    title: 'Clogged Toilet',
    icon: 'BadgeAlert',
    description: 'Toilet that won\'t flush or backs up when flushed.',
    urgencyLevel: 'high',
    estimatedResponseTime: 'Same day',
    commonSolutions: [
      'Professional toilet auger service',
      'Removing and clearing the toilet',
      'Sewer line inspection for recurring issues'
    ]
  },
  {
    id: 'water-heater-issues',
    title: 'Water Heater Issues',
    icon: 'Flame',
    description: 'Problems with water temperature, strange noises, or leaks from water heater.',
    urgencyLevel: 'high',
    estimatedResponseTime: 'Within 4-6 hours',
    commonSolutions: [
      'Heating element replacement',
      'Thermostat repair or replacement',
      'Pressure relief valve service',
      'Complete water heater replacement'
    ]
  },
  {
    id: 'sewer-line-problems',
    title: 'Sewer Line Problems',
    icon: 'PenTool',
    description: 'Backups, foul odors, or multiple drains clogging simultaneously.',
    urgencyLevel: 'emergency',
    estimatedResponseTime: 'Within 1-2 hours',
    commonSolutions: [
      'Sewer line snaking',
      'Video camera inspection',
      'Hydro jetting',
      'Sewer line repair or replacement'
    ]
  },
  {
    id: 'garbage-disposal-malfunction',
    title: 'Garbage Disposal Malfunction',
    icon: 'Trash2',
    description: 'Disposal that won\'t turn on, makes strange noises, or won\'t drain.',
    urgencyLevel: 'medium',
    estimatedResponseTime: 'Same day',
    commonSolutions: [
      'Disposal unjamming',
      'Reset button activation',
      'Motor or component repair',
      'Complete disposal replacement'
    ]
  },
  {
    id: 'sump-pump-failure',
    title: 'Sump Pump Failure',
    icon: 'Cpu',
    description: 'Pump not working during heavy rain, leading to potential flooding.',
    urgencyLevel: 'emergency',
    estimatedResponseTime: 'Within 1-2 hours',
    commonSolutions: [
      'Switch or float mechanism repair',
      'Impeller or pump cleaning',
      'Check valve replacement',
      'Complete pump replacement'
    ]
  },
  {
    id: 'gas-line-concerns',
    title: 'Gas Line Concerns',
    icon: 'AlertTriangle',
    description: 'Suspected gas leaks or need for gas line installation for appliances.',
    urgencyLevel: 'emergency',
    estimatedResponseTime: 'Immediate',
    commonSolutions: [
      'Gas leak detection',
      'Gas line repair',
      'Gas line installation',
      'Gas appliance connection'
    ]
  },
  {
    id: 'fixture-installation',
    title: 'Fixture Installation or Repair',
    icon: 'Wrench',
    description: 'Professional installation or repair of sinks, faucets, toilets, etc.',
    urgencyLevel: 'low',
    estimatedResponseTime: 'Scheduled appointment',
    commonSolutions: [
      'Sink installation',
      'Faucet replacement',
      'Toilet installation',
      'Shower or tub fixture mounting'
    ]
  },
  {
    id: 'preventative-maintenance',
    title: 'Preventative Maintenance',
    icon: 'ShieldCheck',
    description: 'Regular service to prevent plumbing emergencies and extend system life.',
    urgencyLevel: 'low',
    estimatedResponseTime: 'Scheduled appointment',
    commonSolutions: [
      'Annual plumbing inspection',
      'Water heater flushing',
      'Pipe insulation',
      'Sewer line cleaning'
    ]
  },
  {
    id: 'emergency-services',
    title: 'Emergency Plumbing Services',
    icon: 'AlarmClock',
    description: 'Immediate response to severe plumbing issues to prevent damage.',
    urgencyLevel: 'emergency',
    estimatedResponseTime: 'Within 1 hour',
    commonSolutions: [
      'Water shutoff assistance',
      'Emergency pipe repair',
      'Flood cleanup coordination',
      'After-hours service'
    ]
  },
  {
    id: 'commercial-plumbing',
    title: 'Commercial Plumbing Services',
    icon: 'Building2',
    description: 'Specialized plumbing solutions for businesses and commercial properties.',
    urgencyLevel: 'medium',
    estimatedResponseTime: 'Same day or scheduled',
    commonSolutions: [
      'Commercial drain cleaning',
      'Backflow prevention',
      'Code compliance updates',
      'Large-scale plumbing system service'
    ]
  }
];

export default services;