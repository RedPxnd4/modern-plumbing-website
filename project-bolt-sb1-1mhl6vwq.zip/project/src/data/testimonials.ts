import { Testimonial } from '../types';

const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'James Wilson',
    location: 'North Hills',
    service: 'Emergency Pipe Repair',
    rating: 5,
    comment: 'I had a burst pipe at 2 AM and they were at my door within 30 minutes. Professional, efficient, and saved me from major water damage. Couldn\'t be more grateful!',
    imageUrl: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=300',
    serviceId: 'leaky-pipes'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    location: 'Westwood',
    service: 'Water Heater Replacement',
    rating: 5,
    comment: 'After my old water heater failed, they installed a new, energy-efficient model the same day. The technician explained all my options and helped me choose the best one for my family. Highly recommend!',
    imageUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=300',
    serviceId: 'water-heater-issues'
  },
  {
    id: '3',
    name: 'Michael Rodriguez',
    location: 'Eastside',
    service: 'Annual Maintenance',
    rating: 5,
    comment: 'Been using their annual maintenance plan for two years now. Each visit is thorough and they\'ve caught minor issues before they became major problems. Well worth the investment.',
    imageUrl: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=300',
    serviceId: 'preventative-maintenance'
  },
  {
    id: '4',
    name: 'Emma Thompson',
    location: 'Riverdale',
    service: 'Bathroom Remodel',
    rating: 5,
    comment: 'They handled the plumbing for our entire bathroom renovation. From moving pipes to installing new fixtures, everything was done perfectly. Their attention to detail made all the difference.',
    imageUrl: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=300',
    serviceId: 'fixture-installation'
  },
  {
    id: '5',
    name: 'David Chen',
    location: 'Midtown',
    service: 'Sewer Line Repair',
    rating: 5,
    comment: 'What could have been a nightmare sewer line issue was handled quickly and with minimal disruption to our yard. They used modern equipment to diagnose and fix the problem without excessive digging.',
    imageUrl: 'https://images.pexels.com/photos/532220/pexels-photo-532220.jpeg?auto=compress&cs=tinysrgb&w=300',
    serviceId: 'sewer-line-problems'
  }
];

export default testimonials;